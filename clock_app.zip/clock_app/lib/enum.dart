enum MenuType{  //Create different MenuItems
  clock,
  alarm,
  timer,
  stopwatch,
}